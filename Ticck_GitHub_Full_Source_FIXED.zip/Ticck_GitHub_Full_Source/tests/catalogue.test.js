import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import catalogue from '../src/catalogue.json' with {type:'json'};
import {validAmount} from '../src/helpers.js';
const all=catalogue.flatMap(x=>x.commands);
test('550 unique command names in catalogue',()=>{assert.equal(all.length,550);assert.equal(new Set(all).size,550);});
test('all 550 commands have their own real .js file',()=>{for(const name of all){const p=new URL(`../src/commands/${name}.js`,import.meta.url);assert.ok(fs.existsSync(p),name);assert.match(fs.readFileSync(p,'utf8'),/export default async function/);}});
test('virtual coin amounts',()=>{assert.equal(validAmount('all',500),500);assert.equal(validAmount('100',200),100);assert.equal(validAmount('oops',200),null);assert.equal(validAmount('-10',200),null);});
