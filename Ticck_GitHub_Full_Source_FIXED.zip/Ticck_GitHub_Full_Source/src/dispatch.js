import catalogue from './catalogue.json' with {type:'json'};
import {send,COLORS,PREFIX} from './core/ui.js';
import {handlers as original} from './modules/original.js';
import {handlers as information} from './modules/information.js';
import {handlers as moderation} from './modules/moderation.js';
import {handlers as economy} from './modules/economy.js';
import {handlers as games} from './modules/games.js';
import {handlers as social} from './modules/social.js';
import {handlers as levels} from './modules/levels.js';
import {handlers as server} from './modules/server.js';
import {handlers as utility} from './modules/utility.js';
import {handlers as tickets} from './modules/tickets.js';
import {handlers as roles} from './modules/roles.js';
import {handlers as owner} from './modules/owner.js';
import {handlers as automod} from './modules/automod.js';

const implementations={...original,...information,...moderation,...economy,...games,...social,...levels,...server,...utility,...tickets,...roles,...owner,...automod};
// Certain commands have descriptive copy but no complete underlying behaviour.
const incomplete=new Set(['transactions','transferhistory','badges','marry','rewards','levelrewards','ticketpriority','stopwatch']);
const allCommands=new Set(catalogue.flatMap(c=>c.commands));
export const implementedNames=Object.keys(implementations).filter(n=>allCommands.has(n)&&!incomplete.has(n)).sort();
export const plannedNames=[...allCommands].filter(x=>!implementedNames.includes(x));
export async function execute(name,message,args) {
  if(!allCommands.has(name))return false;
  if (name==='help' || name==='commands') {
    const search=(args.join(' ')||'').toLowerCase();
    const cat=search?catalogue.find(x=>x.name.toLowerCase().includes(search)):null;
    if(cat){const working=cat.commands.filter(x=>implementedNames.includes(x));return send(message,`📚 ${cat.name}`,`**Ready (${working.length}/${cat.commands.length}):**\n${working.map(x=>`\`${PREFIX}${x}\``).join(' • ')||'None yet'}\n\nOther commands in this category are planned.`);}
    return send(message,'📚 Ticck • Help',`**Prefix:** \`${PREFIX}\`\n**Coded command handlers:** ${implementedNames.length}/${allCommands.size}\n\nUse \`.categories\` for the sections, \`.help economy\` for a category, or \`.commandinfo COMMAND\` to see its status.`);
  }
  if(name==='commandinfo'){
    const key=(args[0]||'').replace(/^\./,''); const found=catalogue.find(x=>x.commands.includes(key));
    return send(message,'ℹ️ Command Information',found?`**${PREFIX}${key}**\nCategory: ${found.name}\nStatus: ${implementedNames.includes(key)?'✅ Coded handler':'🚧 Not yet implemented'}`:'Command not found.');
  }
  if (name==='searchcommand'){
    const q=args[0]?.toLowerCase();
    const found=q?[...allCommands].filter(x=>x.includes(q)).slice(0,35):[];
    return send(message,'🔎 Search Commands',found.map(x=>`\`${PREFIX}${x}\` ${implementedNames.includes(x)?'✅':'🚧'}`).join('\n')||'Use `.searchcommand ticket`.');
  }
  if (name==='helpall'||name==='categories') return send(message,'📚 All 550 Commands',catalogue.map(x=>`**${x.name}** — ${x.commands.filter(y=>implementedNames.includes(y)).length}/${x.commands.length} coded`).join('\n'));
  if (incomplete.has(name)||!implementations[name])return send(message,`🚧 ${PREFIX}${name} — Planned`,`The \`${PREFIX}${name}\` command has its own source file but **does not have a working implementation yet**. See \`reference/\` for its planned design.`,COLORS.warning);
  return implementations[name](message,args);
}
