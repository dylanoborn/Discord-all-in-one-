import { EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { COLORS, PREFIX, formatCoins, validAmount } from '../helpers.js';
import { getUser, getGuild, save } from '../storage.js';

export {COLORS, PREFIX, formatCoins, validAmount, getUser, getGuild, save};
export function card(title,description,color=COLORS.primary) {
  return new EmbedBuilder().setTitle(String(title).slice(0,256)).setDescription(String(description || ' ').slice(0,4096))
    .setColor(color).setFooter({text:'Ticck • All-in-One Discord Bot'}).setTimestamp();
}
export async function send(message,title,description,color=COLORS.primary) {
  return message.reply({embeds:[card(title,description,color)],allowedMentions:{parse:[],repliedUser:false}});
}
export function admin(message,flag=PermissionFlagsBits.ManageGuild) {
  return Boolean(message.member?.permissions.has(flag) && message.guild.members.me?.permissions.has(flag));
}
export function staff(message,flag=PermissionFlagsBits.ManageMessages) {
  return Boolean(message.member?.permissions.has(flag));
}
export function owner(message) {return !!process.env.BOT_OWNER_ID && message.author.id === process.env.BOT_OWNER_ID;}
export function sumSafe(...nums){const n=nums.reduce((a,b)=>a+b,0);return Number.isSafeInteger(n)&&n>=0?n:null;}
export function asBet(raw,user,max=1_000_000) {
  const n=validAmount(raw,user.money);
  return n && n>=1 && n<=max && user.money>=n ? n : null;
}
export function memberTarget(message,args) {
  const user=message.mentions.users.first();return user || null;
}
export function clean(text, max=1500) {return String(text||'').replaceAll('@everyone','everyone').replaceAll('@here','here').slice(0,max);}
export function mentionSafe(user){return user ? `**${clean(user.username,100)}**` : 'Unknown user';}
export function humanMs(ms) {const s=Math.ceil(ms/1000);return s>=3600?`${Math.ceil(s/3600)}h`:s>=60?`${Math.ceil(s/60)}m`:`${s}s`;}
