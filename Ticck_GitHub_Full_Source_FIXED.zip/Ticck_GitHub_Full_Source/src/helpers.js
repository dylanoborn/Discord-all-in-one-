export const PREFIX = process.env.BOT_PREFIX || '.';
export const COLORS = { primary: 0x5865f2, success: 0x2ecc71, error: 0xed4245, warning: 0xf1c40f, casino: 0xe67e22 };
export function formatCoins(value) { return Math.trunc(value).toLocaleString('en-GB'); }
export function validAmount(text, balance) {
  if (text === 'all') return balance;
  if (!/^[1-9]\d*$/.test(text ?? '')) return null;
  const n = Number(text);
  return Number.isSafeInteger(n) ? n : null;
}
export function randInt(n) { return Math.floor(Math.random() * n); }
