// Ticck command: .setrules
// Source module for this command name. Actual logic is routed through src/dispatch.js.
// Unimplemented features return an honest "planned" embed, not a fake success.
import { execute } from '../dispatch.js';
export default async function run_setrules(message, args) {
  return execute('setrules', message, args);
}
