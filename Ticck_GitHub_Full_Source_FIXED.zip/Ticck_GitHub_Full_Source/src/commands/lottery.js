// Ticck command: .lottery
// Source module for this command name. Actual logic is routed through src/dispatch.js.
// Unimplemented features return an honest "planned" embed, not a fake success.
import { execute } from '../dispatch.js';
export default async function run_lottery(message, args) {
  return execute('lottery', message, args);
}
