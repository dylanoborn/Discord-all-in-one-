import fs from 'node:fs';
import path from 'node:path';

// Prototype JSON storage: suitable only for a small test deployment on persistent disk.
// Do not run two bot processes against the same file. Use a database for production.
const file = path.resolve(process.env.DATA_FILE || './data/state.json');
let state = { users: {}, guilds: {} };
try {
  state = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (!state || typeof state !== 'object' || !state.users) throw Error('Invalid saved state');
} catch (err) { if (err.code !== 'ENOENT') throw err; }
state.guilds ??= {};

export function getUser(id) {
  const u = state.users[id] ??= {};
  for (const [key,value] of Object.entries({money:0,bank:0,bankLimit:10_000_000,lastDaily:0,lastWork:0,xp:0,level:0,inventory:{},businesses:[],reputation:0, friends:[], streak:0})) {
    if (u[key] === undefined) u[key] = structuredClone(value);
  }
  return u;
}
export function getGuild(id) {
  const g = state.guilds[id] ??= {};
  for (const [key,value] of Object.entries({prefix:'.',settings:{},warnings:{},notes:{},tickets:{},cases:[],filters:[],automod:{},xpEnabled:true})) {
    if(g[key] === undefined) g[key] = structuredClone(value);
  }
  return g;
}
export function allUsers() {return Object.entries(state.users);}
export function allGuilds() {return Object.entries(state.guilds);}
export function save() {
  fs.mkdirSync(path.dirname(file), {recursive:true});
  const temp = file + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(state,null,2));
  fs.renameSync(temp,file);
}
