import 'dotenv/config';
import {Client,Events,GatewayIntentBits,Partials} from 'discord.js';
import {getGuild,save} from './storage.js';
import {runReminders,onMessage as afkMessage} from './modules/utility.js';
import {onMessage as autoMessage} from './modules/automod.js';
import {earnXp} from './modules/levels.js';
import {onJoin as autoroleJoin} from './modules/roles.js';
import {onButton as ticketButton} from './modules/tickets.js';
import {send} from './core/ui.js';
import catalogue from './catalogue.json' with {type:'json'};

if(!process.env.DISCORD_TOKEN || process.env.DISCORD_TOKEN==='YOUR_BOT_TOKEN_HERE'){
  console.error('Set DISCORD_TOKEN privately in your hosting environment. Never commit a real token.');
  process.exit(1);
}
const client=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent,GatewayIntentBits.GuildMembers],partials:[Partials.Channel]});
const catalogueNames=new Set(catalogue.flatMap(x=>x.commands));
client.once(Events.ClientReady,c=>console.log(`Ticck is online as ${c.user.tag} • ${catalogueNames.size} command entry files`));
client.on(Events.MessageCreate,async m=>{
  if(m.author.bot||!m.guild)return;
  try{
    if(await autoMessage(m))return;
    await afkMessage(m);
    const prefix=getGuild(m.guild.id).prefix||'.';
    if(!m.content.startsWith(prefix)){earnXp(m);return;}
    const words=m.content.slice(prefix.length).trim().split(/\s+/),name=(words.shift()||'').toLowerCase();
    if(!catalogueNames.has(name))return;
    // Each command loads its own JavaScript file from src/commands/. No bare-name placeholders.
    const {default:run}=await import(`./commands/${name}.js`);
    await run(m,words);
  }catch(err){console.error(`Ticck command error: ${err.stack||err}`);await send(m,'❌ Command Error','The command failed. Ask a server admin to check the bot logs.').catch(()=>{});}
});
client.on(Events.GuildMemberAdd, async m=>{await autoroleJoin(m);const g=getGuild(m.guild.id);const ch=g.settings.welcomeChannel?m.guild.channels.cache.get(g.settings.welcomeChannel):null;if(ch?.isTextBased())await ch.send(`Welcome to **${m.guild.name}**, <@${m.id}>!`).catch(()=>{});});
client.on(Events.InteractionCreate,async i=>{if(!i.isButton())return;try{if(await ticketButton(i))return;}catch(err){console.error('Interaction error',err);if(!i.replied&&!i.deferred)await i.reply({content:'Interaction failed.',ephemeral:true}).catch(()=>{});}});
// Reminders persist on disk; they are checked each minute after reboot.
setInterval(()=>runReminders(client).catch(err=>console.error('Reminder error',err)),60000).unref();
await client.login(process.env.DISCORD_TOKEN);
