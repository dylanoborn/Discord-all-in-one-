import {spawnSync} from 'node:child_process';
import {readdirSync} from 'node:fs';
const paths=['src/index.js','src/dispatch.js','src/helpers.js','src/storage.js','src/core/ui.js',...readdirSync('src/modules').map(n=>'src/modules/'+n)];
for(const path of paths){const result=spawnSync(process.execPath,['--check',path],{encoding:'utf8'});if(result.status!==0){console.error(path,result.stderr);process.exit(1);}}
console.log(`Syntax OK: ${paths.length} source modules. Individual command files are syntax-checked during generation.`);
