// Additional prefix aliases. These are real shortcuts supported by src/index.js.
// Do not alias a name that already exists in src/catalogue.json.
export const ALIASES = Object.freeze({
  h:'help',
  helpme:'help',
  allhelp:'helpall',
  modhelp:'helpmod',
  money:'balance',
  bal:'balance',
  inv:'inventory',
  gamblehelp:'helpgames',
  info:'botinfo',
  latency:'ping',
  casinohelp:'helpgames',
  cmds:'commands',
});
