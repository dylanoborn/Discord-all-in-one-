# Ticck — all-in-one Discord bot (JavaScript / GitHub project)

**Prefix:** `.` | **Catalogue:** 550 unique commands | **Source layout:** one `src/commands/<name>.js` file per command. **Help:** 13 category pages with four navigation buttons.

## Before anything else

This project corrects an earlier starter ZIP that had only 24 coded handlers. It now contains substantial implementations of help, moderation, economy, business, shop, XP, games (virtual coins only), tickets, roles and utilities. The full code for supported features lives in `src/modules/`. The `src/commands/` files are individually named entry points which call their implementations through `src/dispatch.js`.

**This is still not 550 fully functional commands.** All 550 source files exist, but unimplemented commands show a clear `🚧 Planned` embed. In particular, music playback, sophisticated casino games, giveaways and some advanced moderation tools are NOT finished. `.mines` and `.chickenrun` currently use text interactions, not the previous BDFD button layouts. Existing BDFD balances/data do not migrate.

## Where to look

- `START_HERE.txt` — simplest mobile-friendly guide.
- `src/commands/` — 550 named JavaScript command files.
- `src/modules/` — actual implemented command logic grouped by feature.
- `src/index.js` — Discord connection, events, prefix routing and interactions.
- `src/storage.js` — JSON storage for starter use.
- `src/dispatch.js` — actual handler lookup and clear unimplemented statuses.
- `src/help-system.js` and `src/help-layout.js` — all 13 help pages, all 550 commands labelled ✅ or 🚧, live coded-command/alias/slash totals, four navigation buttons.
- `src/aliases.js` — 12 actual prefix aliases.
- `src/catalogue.json` — canonical command list.
- `reference/` — variable/default reference, 550 command descriptions and embed plans from BDFD (not directly runnable JavaScript).
- `.env.example` — secret names; **no tokens included**.

## Install and run

1. In your GitHub repository, upload the **extracted folder contents**, not the ZIP file itself. Replace the previous starter `package.json` and `src/` as one project: that starter used CommonJS while this complete package uses ES modules, so do not mix them. Make the repository **private** if you do not want the code public.
2. In your existing Ticck application, configure the **Message Content Intent** in the Discord Developer Portal. Autorole also requires **Guild Members Intent**.
3. On a Node.js 22.12+ host, set `DISCORD_TOKEN` privately, optionally `BOT_OWNER_ID`, and provide persistent storage.
4. Run `npm install` then `npm start` on the host. GitHub by itself does not run bots 24/7.
5. Shut down any other running bot process using the same Discord application token first.

**Never commit `.env`, a real token, or `data/state.json`.** `.gitignore` already excludes them. Tokens do not belong in chats or screenshots.

## Testing

`npm run check` — syntax validation of all core modules and all 550 command entry files.

`npm test` — checks catalogue uniqueness, the presence of all 550 command source files and amount parsing.

These are source-level tests. Discord API integration and complete runtime gameplay have **not been verified** against a live server. Use a test server first.

## Deployment and data cautions

Data is saved to `data/state.json` and requires a host **persistent disk**. A production deployment should use PostgreSQL or an equivalent durable database, with transaction-safe updates; this prototype JSON storage is not intended for large communities or multiple worker processes. Discord role hierarchy and channel permissions may prevent some commands. Virtual coins have no real-world monetary value.

## What shows in `.help`

Page 1 reports the **550 planned commands**, actual number of coded handlers, **12 aliases**, slash commands (fetched from Discord, may be zero), and 13 pages. The category lists on pages 1–13 show every planned command, with ✅ for an implementation handler and 🚧 for unfinished commands. The `First`, `Previous`, `Next`, `Last` buttons are handled centrally by `src/help-system.js`. This menu describes source-level implemented handlers, not independently verified live gameplay.
