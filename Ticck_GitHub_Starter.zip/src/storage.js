import fs from 'node:fs';
import path from 'node:path';

// A simple persistent store for the *starter* bot. For production scale,
// switch to a database and a persistent disk before adding lots of games.
const file = path.resolve(process.env.DATA_FILE || './data/state.json');
let state = { users: {} };
try {
  state = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (!state || typeof state !== 'object' || !state.users) throw Error('Invalid state');
} catch (err) {
  if (err.code !== 'ENOENT') throw err;
}

const defaultUser = () => ({ money: 0, bank: 0, bankLimit: 10_000_000, lastDaily: 0, lastWork: 0 });
export function getUser(id) {
  if (!state.users[id]) state.users[id] = defaultUser();
  return state.users[id];
}
export function save() {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tempFile = file + '.tmp';
  fs.writeFileSync(tempFile, JSON.stringify(state, null, 2));
  fs.renameSync(tempFile, file);
}
// WARNING: never commit data/state.json. Existing BDFD player data is NOT imported.
