import 'dotenv/config';
import { Client, Events, GatewayIntentBits, Partials } from 'discord.js';
import { PREFIX, COLORS } from './helpers.js';
import { runCommand } from './commands.js';
import { EmbedBuilder } from 'discord.js';

if (!process.env.DISCORD_TOKEN || process.env.DISCORD_TOKEN === 'YOUR_BOT_TOKEN_HERE') {
  console.error('Missing DISCORD_TOKEN. Set it privately in your hosting environment, not in GitHub.');
  process.exit(1);
}
const client = new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent],partials:[Partials.Channel]});
client.once(Events.ClientReady, c => console.log(`Ticck ready: ${c.user.tag}`));
client.on(Events.MessageCreate, async message => {
  if(message.author.bot || !message.guild || !message.content.startsWith(PREFIX)) return;
  const parts=message.content.slice(PREFIX.length).trim().split(/\s+/);
  const name=(parts.shift() || '').toLowerCase();
  try {await runCommand(message,name,parts);} catch(err) {
    console.error(`Command ${name} failed`,err);
    try {await message.reply({embeds:[new EmbedBuilder().setColor(COLORS.error).setTitle('❌ Ticck Error').setDescription('That command failed. Please try again or contact the bot owner.').setFooter({text:'Ticck • All-in-One Discord Bot'})],allowedMentions:{repliedUser:false}});} catch{}
  }
});
client.login(process.env.DISCORD_TOKEN);
