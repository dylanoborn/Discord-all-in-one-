import { EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import catalogue from './catalogue.json' with { type: 'json' };
import { COLORS, PREFIX, formatCoins, validAmount, randInt } from './helpers.js';
import { getUser, save } from './storage.js';

function embed(title, description, color = COLORS.primary) {
  return new EmbedBuilder().setTitle(title).setDescription(description).setColor(color)
    .setFooter({text:'Ticck • All-in-One Discord Bot'}).setTimestamp();
}
async function reply(message, title, description, color) {
  return message.reply({embeds:[embed(title, description, color)], allowedMentions:{repliedUser:false}});
}
function betInput(raw, user) {
  const bet = validAmount(raw, user.money);
  if (!bet || bet < 1 || bet > 1_000_000) return null;
  if (user.money < bet) return null;
  return bet;
}

const handlers = {
  async help(message, args) {
    const cat = (args.join(' ') || '').toLowerCase();
    if (cat) {
      const found = catalogue.find(c => c.name.toLowerCase().includes(cat));
      if (!found) return reply(message, '❌ Category not found', `Try \`${PREFIX}categories\`.`, COLORS.error);
      const enabled = found.commands.filter(x => handlers[x]);
      return reply(message, `📚 ${found.name}`, `**Working now (${enabled.length}):** ${enabled.length ? enabled.map(x=>`\`${PREFIX}${x}\``).join(', ') : 'None yet'}\n\n**Planned (${found.commands.length-enabled.length}):** See \`reference/Ticck_550_Commands.txt\` in GitHub.`);
    }
    return reply(message, '📚 Ticck • Help', `**Prefix:** \`${PREFIX}\`\n**Working commands (${Object.keys(handlers).length}):**\n${Object.keys(handlers).sort().map(x=>`\`${PREFIX}${x}\``).join(', ')}\n\n\`${PREFIX}categories\` — all planned categories\n\`${PREFIX}help economy\` — example category`);
  },
  async helpall(message) {
    return reply(message, '📚 Ticck • 550-Command Plan', `${catalogue.map(c=>`**${c.name}:** ${c.commands.length}`).join('\n')}\n\n**Total:** ${catalogue.reduce((s,c)=>s+c.commands.length,0)} planned commands. Not all are implemented yet.`);
  },
  async commands(message) { return handlers.help(message, []); },
  async categories(message) { return handlers.helpall(message); },
  async commandinfo(message,args) {
    const name = (args[0] || '').replace(/^\./,'').toLowerCase();
    if (!name) return reply(message,'ℹ️ Command Info',`Use \`${PREFIX}commandinfo ping\`.`);
    const cat = catalogue.find(c=>c.commands.includes(name));
    if (!cat) return reply(message,'❌ Unknown command',`No planned command named \`${name}\`.`, COLORS.error);
    return reply(message,'ℹ️ Command Info',`**Name:** \`${PREFIX}${name}\`\n**Category:** ${cat.name}\n**Status:** ${handlers[name]?'✅ Working':'🛠️ Planned (not coded yet)'}`);
  },
  async searchcommand(message,args) {
    const search = args.join('').toLowerCase();
    if (!search) return reply(message,'🔎 Search',`Use \`${PREFIX}searchcommand ticket\`.`);
    const hits = catalogue.flatMap(c=>c.commands.filter(x=>x.includes(search)).map(x=>`${PREFIX}${x}${handlers[x]?' ✅':''}`)).slice(0,35);
    return reply(message,'🔎 Command Search', hits.length?hits.map(x=>`\`${x}\``).join(' • '):'No matching commands.');
  },
  async ping(message) {
    return reply(message,'🏓 Pong!',`Bot latency: **${Date.now()-message.createdTimestamp} ms**\nGateway ping: **${Math.round(message.client.ws.ping)} ms**`,COLORS.success);
  },
  async uptime(message) {
    return reply(message,'⏱️ Uptime',`Online for **${Math.floor(message.client.uptime / 60_000).toLocaleString('en-GB')} minutes**.`);
  },
  async botinfo(message) {
    return reply(message,'🤖 Ticck • Bot Info',`**Prefix:** \`${PREFIX}\`\n**Servers:** ${message.client.guilds.cache.size}\n**Working commands:** ${Object.keys(handlers).length}\n**Planned:** 550`);
  },
  async invite(message) {
    return reply(message,'🔗 Invite Ticck',`[Add Ticck to a server](https://discord.com/oauth2/authorize?client_id=${message.client.user.id}&scope=bot%20applications.commands&permissions=274878295104)`);
  },
  async balance(message) {
    const u = getUser(message.author.id);
    return reply(message,'💰 Your Balance',`**Wallet:** ${formatCoins(u.money)} coins\n**Bank:** ${formatCoins(u.bank)} coins\n**Total:** ${formatCoins(u.money+u.bank)} coins\n**Bank capacity:** ${formatCoins(u.bankLimit)} coins`);
  },
  async wallet(message) {return handlers.balance(message);},
  async bank(message) {return handlers.balance(message);},
  async daily(message) {
    const u = getUser(message.author.id); const now=Date.now();
    const remaining = 86_400_000 - (now-u.lastDaily);
    if (remaining>0) return reply(message,'⏳ Daily Reward',`Claim again in **${Math.ceil(remaining/3_600_000)} hour(s)**.`,COLORS.warning);
    u.money+=5_000;u.lastDaily=now;save();
    return reply(message,'🎁 Daily Reward',`You collected **5,000 virtual coins**!\nWallet: ${formatCoins(u.money)}`,COLORS.success);
  },
  async work(message) {
    const u=getUser(message.author.id);const now=Date.now();const left=600_000-(now-u.lastWork);
    if(left>0) return reply(message,'⏳ Work Cooldown',`Try again in **${Math.ceil(left/60_000)} minute(s)**.`,COLORS.warning);
    const reward=100+randInt(901);u.money+=reward;u.lastWork=now;save();
    return reply(message,'💼 Work Complete',`You earned **${formatCoins(reward)} virtual coins**!`,COLORS.success);
  },
  async deposit(message,args) {
    const u=getUser(message.author.id);const n=validAmount(args[0],u.money);
    if(!n||n<1||n>u.money||n>u.bankLimit-u.bank)
      return reply(message,'❌ Invalid Deposit',`Use \`${PREFIX}deposit 1000\` or \`${PREFIX}deposit all\` (must fit bank capacity).`,COLORS.error);
    u.money-=n;u.bank+=n;save();return reply(message,'🏦 Deposit Successful',`Deposited **${formatCoins(n)} coins**.`,COLORS.success);
  },
  async withdraw(message,args) {
    const u=getUser(message.author.id);const n=validAmount(args[0],u.bank);
    if(!n||n<1||n>u.bank||!Number.isSafeInteger(u.money+n))
      return reply(message,'❌ Invalid Withdrawal',`Use \`${PREFIX}withdraw 1000\` or \`${PREFIX}withdraw all\`.`,COLORS.error);
    u.bank-=n;u.money+=n;save();return reply(message,'🏦 Withdrawal Successful',`Withdrew **${formatCoins(n)} coins**.`,COLORS.success);
  },
  async pay(message,args) {
    const target=message.mentions.users.first();const u=getUser(message.author.id);
    const n=validAmount(args[0],u.money);
    if(!target||target.bot||target.id===message.author.id||!n||n<1||n>u.money)
      return reply(message,'❌ Invalid Transfer',`Use \`${PREFIX}pay 1000 @user\` (virtual coins only).`,COLORS.error);
    const to=getUser(target.id);
    if(!Number.isSafeInteger(to.money+n)) return reply(message,'❌ Transfer Too Large','Recipient would exceed the supported balance.',COLORS.error);
    u.money-=n;to.money+=n;save();
    return reply(message,'💸 Transfer Complete',`Sent **${formatCoins(n)} coins** to ${target.username}.`,COLORS.success);
  },
  async transfer(message,args) {return handlers.pay(message,args);},
  async coinflip(message,args) {
    const u=getUser(message.author.id);const choice=(args[0]||'').toLowerCase();
    if(!['heads','tails'].includes(choice)) return reply(message,'🪙 Coin Flip',`Use \`${PREFIX}coinflip heads\` or \`${PREFIX}coinflip tails 100\` (optional virtual bet).`);
    const bet=args[1]===undefined?0:betInput(args[1],u);
    if(bet===null) return reply(message,'❌ Invalid Bet','Bet must be between 1 and 1,000,000 coins and fit in your wallet.',COLORS.error);
    const result=randInt(2)?'heads':'tails';let text=`You picked **${choice}**.\nResult: **${result}**.`;
    if(bet){const delta=choice===result?bet:-bet;u.money+=delta;save();text+=`\n${delta>0?'✅ Won':'❌ Lost'} **${formatCoins(bet)} virtual coins**.`;}
    return reply(message,'🪙 Coin Flip',text,COLORS.casino);
  },
  async dice(message) {return reply(message,'🎲 Dice',`You rolled **${1+randInt(6)}**!`,COLORS.casino);},
  async roll(message) {return handlers.dice(message);},
  async slots(message,args) {
    const u=getUser(message.author.id);const bet=betInput(args[0],u);
    if(!bet) return reply(message,'🎰 Slots',`Use \`${PREFIX}slots 100\`. Bet 1–1,000,000 virtual coins from your wallet.`,COLORS.error);
    const icons=['🍒','🍋','🍇','🔔','💎'];const draws=Array.from({length:3},()=>icons[randInt(icons.length)]);
    const counts=new Set(draws).size;const payout=counts===1?bet*5:counts===2?Math.floor(bet*1.5):0;
    u.money=u.money-bet+payout;save();
    return reply(message,'🎰 Ticck Slots',`${draws.join(' | ')}\n\n**Bet:** ${formatCoins(bet)}\n**Payout:** ${formatCoins(payout)}\n**Wallet:** ${formatCoins(u.money)}\n\nVirtual coins only.`,COLORS.casino);
  },
  async clear(message,args) {
    if(!message.member?.permissions.has(PermissionFlagsBits.ManageMessages) || !message.guild.members.me?.permissions.has(PermissionFlagsBits.ManageMessages))
      return reply(message,'❌ Missing Permissions','You and the bot both need **Manage Messages**.',COLORS.error);
    const n=Number(args[0]);
    if(!Number.isInteger(n)||n<1||n>99) return reply(message,'🧹 Clear Messages',`Use \`${PREFIX}clear 10\` (1–99 recent messages).`);
    const deleted=await message.channel.bulkDelete(n+1,true);
    const notice=await message.channel.send({embeds:[embed('🧹 Messages Cleared',`Deleted **${deleted.size}** recent messages.`,COLORS.success)]});
    setTimeout(()=>notice.delete().catch(()=>{}),5000);
  },
};

export async function runCommand(message,name,args) {
  const fn=handlers[name];
  if(!fn) return false;
  await fn(message,args);return true;
}
export const workingCommands=Object.keys(handlers);
