import test from 'node:test';
import assert from 'node:assert/strict';
import catalogue from '../src/catalogue.json' with {type:'json'};
import {validAmount} from '../src/helpers.js';
test('catalogue has 550 unique commands',()=>{
 const all=catalogue.flatMap(c=>c.commands);
 assert.equal(all.length,550);
 assert.equal(new Set(all).size,550);
});
test('amount validation',()=>{
 assert.equal(validAmount('all',500),500);
 assert.equal(validAmount('1000',500),1000);
 assert.equal(validAmount('-20',500),null);
 assert.equal(validAmount('1.2',500),null);
 assert.equal(validAmount('999999999999999999999',500),null);
});
