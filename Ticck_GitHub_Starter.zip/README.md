# Ticck — All-in-One Discord Bot (GitHub Starter)

Ticck is a Discord bot project using **JavaScript, discord.js and the `.` prefix**. All visible command responses are embeds. Gambling uses **virtual in-bot coins only**; no monetary deposits, withdrawals or real-money prizes.

## What is actually working now?

`help`, `helpall`, `commands`, `categories`, `commandinfo`, `searchcommand`, `ping`, `uptime`, `botinfo`, `invite`, `balance`, `wallet`, `bank`, `daily`, `work`, `deposit`, `withdraw`, `pay`, `transfer`, `coinflip`, `dice`, `roll`, `slots` and `clear`.

**Not yet implemented:** Most of the 550-command roadmap, including Tickets, Chicken Run, Mines, music playback, many moderation commands, buttons, advanced financial games, and migration of old BDFD player data. Do not claim the whole bot is finished just because a command appears in `src/catalogue.json`.

## What's included

- `src/catalogue.json`: planned list of **550 distinct commands**, organised by category.
- `reference/`: original command catalogue, BDFD variable/default reference and designs for all 550 command embeds.
- `src/index.js`: Discord event handler.
- `src/commands.js`: actually implemented commands with embed responses.
- `src/storage.js`: prototype saved-wallet data (local JSON file on the host).
- `.env.example`: example token configuration **without an actual token**.
- `tests/`: starter integrity checks.

## Step 1 — Make a private GitHub repository

On GitHub, tap **+ → New repository**, name it **`ticck-bot`**, choose **Private**, and create it. Upload the **contents of this project folder** (not just the .zip). Or ask ChatGPT to add the files once GitHub is connected and the repository exists.

## Step 2 — Configure the Discord application

Open [Discord Developer Portal](https://discord.com/developers/applications). Select your existing Ticck bot application; do **not** create a second bot unless you want a different bot account. Under Bot → Privileged Gateway Intents, enable **Message Content Intent** for `.` prefix messages (if eligible). Ensure the bot has appropriate permissions in your server. Discord may require a review for access based on your bot's audience.

## Step 3 — Host the bot

GitHub is **source control, not 24/7 bot hosting**. Use a persistent hosting service such as a VPS or another Node.js host. The host must support **Node.js 24.17.0+**. Configure the secret **DISCORD_TOKEN** on the host's private environment variables page; optionally set **BOT_PREFIX** to `.`. Never place the token in a file committed to GitHub, a screenshot, or a chat.

Install and start on the host:

```sh
npm install
npm start
```

Optional checks (Node 24.17+):

```sh
npm test
npm run check
```

**Keep exactly one live process using the same Discord token.** Turn off the existing BDFD bot connection before running this replacement, so commands don't execute twice. No old user balances/settings are transferred automatically.

## Data persistence

`data/state.json` is intentionally ignored by Git. The host must provide a **persistent disk**, or balances and progress can vanish when the bot is redeployed. This starter's JSON file is suitable only for initial small-bot testing. For a production bot serving many users, move storage to PostgreSQL or another durable database and implement transaction-safe changes before expanding gambling or transfers.

## Next features

Recommended build order: 1) help navigation + owner settings, 2) economy & persistent database, 3) moderation & logs, 4) tickets, 5) Mines/Chicken Run and other virtual casino games, 6) businesses, 7) music and Lavalink, 8) deploy and test full 550-command roadmap.

## BDFD migration warning

BDScript 2 and JavaScript are different programming languages. The reference variables are **planning notes**, not magically migrated or working values. Reimplement BDFD commands in JavaScript and plan a safe export/import of old user data where BDFD access permits.
